import { deletedata, getdata, saveData, updatedata } from "./context.services";

const url =" http://localhost:3000/propertyties";

export function saveProperty(data) {
    return saveData(url, data);

}

export function getProperty() {
    return getdata(url);
}

export function updateProperty(url, data) {
    return updatedata(url, data);
}
export function deleteProperty(url){
    return deletedata(url);
}

