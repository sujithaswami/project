import { Routes ,Route} from "react-router-dom";
import { Menu } from "./components/admin/menu/menu.component";
import { PropertyView } from "./components/admin/properties-view/properties-viewcomponent";
import { PropertyTypeView } from "./components/admin/property-type-view/property-type-view.component";
import { Properties } from "./components/admin/properties/properties.components";

export function AppRouter(){
    return(
        <Routes>
            <Route path="/property-type" element={<Properties></Properties>}></Route>
            <Route path="/add-property-types" element={<PropertyTypeView></PropertyTypeView>}></Route>
        </Routes>
    )
}