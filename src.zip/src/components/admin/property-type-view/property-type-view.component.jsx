import { useEffect, useState } from "react";
import { getPropertyType } from "../../../services/propert-type.service";

export function PropertyTypeView() {

    const [propertyTypes, setPropertyTypes] = useState([]);

    useEffect(()=>{
        getPropertyType().then(
            (res)=>{
                setPropertyTypes(res.data);
            }
        );
    }, []);

    return (
        <div>
            <h2>Property Types</h2>
            <table className="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Desc.</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        propertyTypes && propertyTypes.map((item)=>
                            <tr>
                                <td>{ item.id }</td>
                                <td>{ item.PropertyType }</td>
                                <td>{ item.description }</td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    )
}
