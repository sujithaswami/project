import { Button } from "bootstrap";
import {savePropertyType}from '../../../services/propert-type.service';

export function PropertyType() {
    function savedate(){
        //alert(document.getElementById("properttype").value);
        let data={
            PropertyType: document.getElementById("properttype").value, 
            description: document.getElementById("description").value
        }
        savePropertyType(data).then((res)=>{
            alert("Data saved");
            document.getElementById("properttype").value = "";
            document.getElementById("description").value = "";  
        }).catch(()=>{

        }); 

    }
    return (
        <div>
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">Property Type</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="properttype"></input>
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label" >Description</label>
                <div class="col-sm-10">
                    <textarea className="form-control" id="description"></textarea>
                </div>

            </div>
            <div>
               <input type="button" className="btn btn-primary" value="save"  onClick={()=> {savedate()}}></input>
               <input type="button" className="btn btn-secondary m1-1" value="cancle"></input> 
            </div>


        </div>
    )
}
