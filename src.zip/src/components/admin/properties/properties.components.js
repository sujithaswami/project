import { Button } from "bootstrap";
import { saveProperty } from "../../../services/properties";

export function Properties(){
    function savedate(){
        //alert(document.getElementById('propertytype').value)

        let data={
            PropertyType: document.getElementById("propertytype").value, 
            Propertyname: document.getElementById("propertyname").value,
            Measurements: document.getElementById("measurements").value,
            Address: document.getElementById("address").value
        }
        saveProperty(data).then((res)=>{
            alert("Data saved");
            document.getElementById("propertytype").value = "";
            document.getElementById("propertyname").value = ""; 
            document.getElementById("measurements").value = ""; 
            document.getElementById("address").value = ""; 

        }).catch(()=>{

        }); 
    }
    return(
        <div>
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">Property Type</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="propertytype"></input>
                </div>
            </div>
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">Property name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control"  id="propertyname"></input>
                </div>
            </div>
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">Measurements</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control"  id="measurements"></input>
                </div>
            </div>
            
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label" >Address</label>
                <div class="col-sm-10">
                    <textarea className="form-control" id="address"></textarea>
                </div>

            </div>
            <div>
               <input type="button" className="btn btn-primary" value="save"  onClick={()=> {savedate()}}></input>
               <input type="button" className="btn btn-secondary ml-1" value="cancle"></input> 
            </div>


        </div>



    )
}