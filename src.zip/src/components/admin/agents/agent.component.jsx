import { saveAgentData} from '../../../services/agent.services';

export function Agents() {
    function savedate(){
        //alert(document.getElementById('name').value)
        let agentdata={
            Name: document.getElementById('name').value,
            Email: document.getElementById('email').value,
            gender: document.getElementById('gender').value,
            Age: document.getElementById('age').value,
            Address: document.getElementById('address').value

        }

        
    }
    return (
        <div>
            <div class="form-group row">
                <label for="staticname" class="col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="name"></input>
                </div>
            </div>
            <div class="form-group row">
                <label for="staticemail" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="email"></input>
                </div>
            </div>
            <div class="form-group row">
                <label for="staticemail" class="col-sm-2 col-form-label">Gender</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="gender"></input>
                </div>
            </div>
            <div class="form-group row">
                <label for="staticemail" class="col-sm-2 col-form-label">Age</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="age"></input>
                </div>
            </div>
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label" >Address</label>
                <div class="col-sm-10">
                    <textarea className="form-control"id="address" ></textarea>
                </div>
            </div>
            <div>
                <input type="button" className="btn btn-primary" value="save" onClick={() => { savedate() }}></input>
                <input type="button" className="btn btn-secondary m1-1" value="cancle"></input>
            </div>
        </div>




    )
}
