import { useEffect, useState } from "react";
import { getProperty } from "../../../services/properties";

export function PropertyView() {

    const [properties, setProperties] = useState([]);

    useEffect(()=>{
        getProperty().then(
            (res)=>{
                setProperties(res.data);
            }
        );
    }, []);

    return (
        <div>
            <h2>Propertiess</h2>
            <table className="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>property Type</th>
                        <th>property name</th>
                        <th>Measurements</th>
                        <th>Address</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        properties && properties.map((item)=>
                            <tr>
                                <td>{ item.id }</td>
                                <td>{ item.PropertyType }</td>
                                <td> {item.Propertyname}</td>
                                <td>{ item.Measurements}</td>
                                <td>{ item.Address}</td>

                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    )
}
