import logo from './logo.svg';
import './App.css';
import { Menu } from './components/admin/menu/menu.component';

import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

import { Properties } from './components/admin/properties/properties.components';
import { PropertyView } from './components/admin/properties-view/properties-viewcomponent';
// import { AppRouter } from './app.router';
import { BrowserRouter } from 'react-router-dom';




function App() {
  return (
    <BrowserRouter>
    <Menu></Menu>
    {/* <AppRouter></AppRouter> */}
    
    </BrowserRouter>

  );
}

export default App;
