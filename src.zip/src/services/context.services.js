import axios from 'axios';

export function saveData(url, data){
    return axios.post(url, data)
}

export function getdata(url){
    return axios.get(url)
}

export function updatedata(url, data){
    return axios.post(url, data)
}

export function deletedata(url){
    return axios.post(url)
}

