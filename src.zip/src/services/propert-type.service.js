import { deletedata, getdata, saveData, updatedata } from "./context.services";

const url ="  http://localhost:3000/Propertyttype";

export function savePropertyType(data) {
    return saveData(url, data);

}

export function getPropertyType() {
    return getdata(url);
}

export function updatePropertyType(url, data) {
    return updatedata(url, data);
}
export function deletePropertyType(url){
    return deletedata(url);
}


                          


    