import { deletedata, getdata, saveData, updatedata } from "./context.services";

const url ="";

export function saveAgentData(data) {
    return saveData(url, data);

}

export function getAgentData() {
    return getdata(url);
}

export function updateAgentData(url, data) {
    return updatedata(url, data);
}
export function deleteAgentData(url){
    return deletedata(url);
}